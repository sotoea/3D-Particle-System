/*
 Created by Tom Woudenberg and Eduardo Soto
 Monday December 2, 2013
 Assignment 3
 based off of R.Teather lighting code
 
 */

#ifndef __assignment3__saving__
#define __assignment3__saving__

#include <iostream>

void saveGame(void);

void saveObjects(void);


#endif /* defined(__assignment3__saving__) */
